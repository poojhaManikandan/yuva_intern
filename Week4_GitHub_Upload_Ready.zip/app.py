from flask import Flask, render_template, request
import pickle
import pandas as pd

app = Flask(__name__)

with open("placement_model.pkl", "rb") as f:
    model = pickle.load(f)

@app.route("/", methods=["GET", "POST"])
def home():
    prediction = None
    probability = None
    error = None

    if request.method == "POST":
        try:
            row = pd.DataFrame([{
                "Gender": request.form["gender"],
                "City": request.form["city"],
                "Study_Hours": float(request.form["study_hours"]),
                "Attendance_Percent": float(request.form["attendance"]),
                "Assignments_Completed": float(request.form["assignments"]),
                "Previous_Score": float(request.form["previous_score"]),
                "Internet_Access": request.form["internet"]
            }])

            pred = int(model.predict(row)[0])
            prob = float(model.predict_proba(row)[0][1])

            prediction = "Likely to be placed" if pred == 1 else "Less likely to be placed"
            probability = f"{prob * 100:.2f}%"

        except Exception as exc:
            error = "Please enter valid values in all fields."

    return render_template(
        "index.html",
        prediction=prediction,
        probability=probability,
        error=error
    )

if __name__ == "__main__":
    app.run(debug=True)
