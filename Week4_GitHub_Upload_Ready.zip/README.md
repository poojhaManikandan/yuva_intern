# Week 4 - AI Project Deployment & Capstone

## Student Placement Prediction Web Application

This project demonstrates an end-to-end machine-learning workflow:
1. Load the cleaned dataset
2. Prepare features and target
3. Train a Random Forest classification model
4. Evaluate the model
5. Serialize the complete preprocessing + model pipeline using Pickle
6. Load the saved model in a Flask application
7. Accept user input through a web form
8. Return a placement prediction and probability

## Model
Random Forest Classifier with:
- 150 trees
- Maximum depth: 3
- Minimum samples split: 5
- Random state: 42

## Evaluation
Accuracy: 0.500
Precision: 0.533
Recall: 0.615
F1 Score: 0.571
ROC-AUC: 0.455

## Run locally

```bash
pip install -r requirements.txt
python app.py
```

Then open `http://127.0.0.1:5000/`.

## Files
- `app.py` - Flask prediction API/web application
- `placement_model.pkl` - serialized trained model pipeline
- `templates/index.html` - user interface
- `student_performance_clean.csv` - dataset
- `model_metrics.csv` - evaluation metrics
- `confusion_matrix.csv` - confusion matrix
- `Week4_AI_Project_Deployment_Report_Black.docx` - internship report
