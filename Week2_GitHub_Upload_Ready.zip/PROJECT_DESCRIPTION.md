# Week 2: Supervised Machine Learning Models

This project implements supervised learning for both regression and classification using Scikit-learn.

## Regression
- Linear Regression
- Decision Tree Regressor
- Random Forest Regressor

Target: Final_Score

Metrics: MAE, RMSE, R²

## Classification
- Logistic Regression
- Decision Tree Classifier
- Random Forest Classifier
- K-Nearest Neighbors

Target: Placement

Metrics: Accuracy, Precision, Recall, F1-score

The project uses the cleaned dataset prepared during Week 1 and applies a reproducible 80/20 train-test split with a Scikit-learn preprocessing pipeline.
