# Week 2 - Supervised Machine Learning Models

This project extends the Week 1 preprocessing workflow by training supervised machine-learning models.

## Tasks completed
### Regression
- Linear Regression
- Decision Tree Regressor
- Random Forest Regressor

Target: `Final_Score`

### Classification
- Logistic Regression
- Decision Tree Classifier
- Random Forest Classifier
- K-Nearest Neighbors

Target: `Placement`

## Evaluation
Regression metrics:
- MAE
- RMSE
- R²

Classification metrics:
- Accuracy
- Precision
- Recall
- F1-score

The same train/test split and preprocessing pipeline were used for comparable evaluation.

## Dataset
The Week 1 cleaned student-performance dataset is used as the input.

## Files
- `student_performance_clean.csv`
- `week2_supervised_ml.py`
- `regression_results.csv`
- `classification_results.csv`
- `regression_model_comparison.png`
- `classification_model_comparison.png`
- `classification_confusion_matrix.png`
- `Week2_Supervised_ML_Report_Black.docx`

## Reproduce
```bash
pip install -r requirements.txt
python week2_supervised_ml.py
```
