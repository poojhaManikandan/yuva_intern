import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.tree import DecisionTreeRegressor, DecisionTreeClassifier
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import (
    mean_absolute_error, mean_squared_error, r2_score,
    accuracy_score, precision_score, recall_score, f1_score
)

df = pd.read_csv("student_performance_clean.csv")

features = [
    "Gender", "City", "Study_Hours", "Attendance_Percent",
    "Assignments_Completed", "Previous_Score", "Internet_Access"
]
X = df[features]

numeric = ["Study_Hours", "Attendance_Percent",
           "Assignments_Completed", "Previous_Score"]
categorical = ["Gender", "City", "Internet_Access"]

preprocessor = ColumnTransformer([
    ("num", StandardScaler(), numeric),
    ("cat", OneHotEncoder(handle_unknown="ignore", drop="first"), categorical)
])

# ---------------- Regression: predict Final_Score ----------------
y_reg = df["Final_Score"]
X_train, X_test, y_train, y_test = train_test_split(
    X, y_reg, test_size=0.2, random_state=42
)

reg_models = {
    "Linear Regression": LinearRegression(),
    "Decision Tree Regressor": DecisionTreeRegressor(
        max_depth=4, random_state=42
    ),
    "Random Forest Regressor": RandomForestRegressor(
        n_estimators=150, max_depth=6, random_state=42
    )
}

for name, model in reg_models.items():
    pipe = Pipeline([("prep", preprocessor), ("model", model)])
    pipe.fit(X_train, y_train)
    pred = pipe.predict(X_test)
    print("\n", name)
    print("MAE:", mean_absolute_error(y_test, pred))
    print("RMSE:", mean_squared_error(y_test, pred) ** 0.5)
    print("R2:", r2_score(y_test, pred))

# ---------------- Classification: predict Placement ----------------
y_clf = df["Placement"].map({"No": 0, "Yes": 1})
X_train, X_test, y_train, y_test = train_test_split(
    X, y_clf, test_size=0.2, random_state=42, stratify=y_clf
)

clf_models = {
    "Logistic Regression": LogisticRegression(max_iter=1000),
    "Decision Tree Classifier": DecisionTreeClassifier(
        max_depth=4, random_state=42
    ),
    "Random Forest Classifier": RandomForestClassifier(
        n_estimators=150, max_depth=6, random_state=42
    ),
    "K-Nearest Neighbors": KNeighborsClassifier(n_neighbors=7)
}

for name, model in clf_models.items():
    pipe = Pipeline([("prep", preprocessor), ("model", model)])
    pipe.fit(X_train, y_train)
    pred = pipe.predict(X_test)
    print("\n", name)
    print("Accuracy:", accuracy_score(y_test, pred))
    print("Precision:", precision_score(y_test, pred, zero_division=0))
    print("Recall:", recall_score(y_test, pred, zero_division=0))
    print("F1:", f1_score(y_test, pred, zero_division=0))
