import pandas as pd
import numpy as np

RAW_FILE = "student_performance_raw.csv"

df = pd.read_csv(RAW_FILE)

print("Initial shape:", df.shape)
print("\nMissing values:\n", df.isnull().sum())
print("\nDuplicate rows:", df.duplicated().sum())

# Remove duplicate records
df = df.drop_duplicates()

numeric_cols = [
    "Study_Hours", "Attendance_Percent",
    "Assignments_Completed", "Previous_Score", "Final_Score"
]
categorical_cols = ["Gender", "City", "Internet_Access", "Placement"]

# Handle missing values
for col in numeric_cols:
    df[col] = df[col].fillna(df[col].median())

for col in categorical_cols:
    df[col] = df[col].fillna(df[col].mode()[0])

# Exploratory Data Analysis
print("\nDescriptive statistics:")
print(df.describe())

print("\nAverage final score by gender:")
print(df.groupby("Gender")["Final_Score"].mean())

# Encode categorical predictors
target = df["Placement"].map({"No": 0, "Yes": 1})
X = df.drop(columns=["Student_ID", "Placement"])
X_encoded = pd.get_dummies(
    X,
    columns=["Gender", "City", "Internet_Access"],
    drop_first=True,
    dtype=int
)

# Feature selection using correlation with target
corr = X_encoded.assign(Placement=target).corr(numeric_only=True)["Placement"]
corr = corr.drop("Placement").abs().sort_values(ascending=False)
selected_features = corr.head(5).index.tolist()
print("\nSelected features:", selected_features)

# Min-Max normalization
for col in numeric_cols[:-1]:
    min_value = X_encoded[col].min()
    max_value = X_encoded[col].max()
    X_encoded[col] = (X_encoded[col] - min_value) / (
        max_value - min_value
    )

X_encoded["Placement"] = target
X_encoded.to_csv("student_performance_processed.csv", index=False)

print("\nPreprocessing completed.")
