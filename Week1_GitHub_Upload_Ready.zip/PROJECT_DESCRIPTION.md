# Week 1: Python for Machine Learning & Data Preprocessing

This project demonstrates a basic data-preprocessing workflow using Python.

## Work completed
- Loaded and inspected a CSV dataset using Pandas
- Identified missing values and duplicate records
- Removed duplicate records
- Filled missing numerical values using the median
- Filled missing categorical values using the mode
- Encoded categorical variables using one-hot encoding
- Converted the placement target into 0/1
- Applied basic correlation-based feature selection
- Applied Min-Max normalization
- Performed basic exploratory data analysis

## Files
- `student_performance_raw.csv` – original dataset
- `student_performance_clean.csv` – cleaned dataset
- `student_performance_encoded.csv` – encoded dataset
- `student_performance_normalized.csv` – normalized/model-ready dataset
- `week1_preprocessing.py` – Python implementation
- `requirements.txt` – required Python packages

## Run
```bash
pip install -r requirements.txt
python week1_preprocessing.py
```
