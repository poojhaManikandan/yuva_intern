# Week 1 - Python for Machine Learning & Data Preprocessing

## Internship Task
Clean and preprocess a sample dataset and document each preprocessing step.

## Dataset
`student_performance_raw.csv` is a sample student-performance dataset created for this internship task. It contains numerical and categorical variables, intentionally introduced missing values, and one duplicate record so that preprocessing techniques can be demonstrated.

## Techniques Used
- Python, NumPy and Pandas
- Data loading and inspection
- Missing-value handling
- Duplicate removal
- Categorical encoding using one-hot encoding
- Min-Max normalization
- Exploratory data analysis
- Correlation-based feature selection
- Exporting processed datasets

## Files
- `student_performance_raw.csv` - raw sample data
- `student_performance_clean.csv` - cleaned data
- `student_performance_encoded.csv` - encoded features
- `student_performance_normalized.csv` - normalized data
- `week1_preprocessing.py` - runnable Python implementation
- `final_score_distribution.png` - EDA visualization
- `study_hours_vs_final_score.png` - EDA visualization
- `Week1_Internship_Report.docx` - internship report

## Run
```bash
pip install pandas numpy matplotlib scikit-learn
python week1_preprocessing.py
```

## Result
Initial rows: 121
Duplicate rows removed: 1
Initial missing cells: 17
Final cleaned rows: 120
Selected features: City_Erode, Study_Hours, Internet_Access_Yes, City_Salem, City_Namakkal
