# Week 3 - Unsupervised Learning & Model Evaluation

This project covers K-Means clustering, hierarchical clustering, PCA dimensionality reduction, and model evaluation.

## Unsupervised Learning
- K-Means clustering for K=2 to 6
- Silhouette Score
- Davies-Bouldin Index
- Calinski-Harabasz Index
- Hierarchical/Agglomerative Clustering
- PCA 2D projection

The K value used for the main K-Means experiment was selected from the clustering evaluation experiment using the highest silhouette score.

## Model Evaluation
A Random Forest classifier was evaluated using:
- 5-fold stratified cross-validation
- Confusion matrix
- Accuracy
- Precision
- Recall
- F1-score
- ROC-AUC
- GridSearchCV hyperparameter tuning

## Files
- `student_performance_clean.csv`
- `student_performance_clustered.csv`
- `kmeans_cluster_metrics.csv`
- `cluster_profiles.csv`
- `pca_cluster_projection.csv`
- `week3_unsupervised_evaluation.py`
- evaluation CSVs and plots
- `Week3_Unsupervised_Model_Evaluation_Report_Black.docx`

## Run
```bash
pip install -r requirements.txt
python week3_unsupervised_evaluation.py
```
