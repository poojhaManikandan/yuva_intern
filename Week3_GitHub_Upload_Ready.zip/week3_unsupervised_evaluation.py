import pandas as pd
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.cluster import KMeans, AgglomerativeClustering
from sklearn.decomposition import PCA
from sklearn.metrics import (
    silhouette_score, davies_bouldin_score, calinski_harabasz_score,
    accuracy_score, precision_score, recall_score, f1_score, roc_auc_score
)
from sklearn.model_selection import StratifiedKFold, cross_val_score, GridSearchCV, train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestClassifier

df = pd.read_csv("student_performance_clean.csv")

# ---------------- Unsupervised learning ----------------
cluster_cols = [
    "Study_Hours", "Attendance_Percent",
    "Assignments_Completed", "Previous_Score", "Final_Score"
]
X_cluster = StandardScaler().fit_transform(df[cluster_cols])

for k in range(2, 7):
    km = KMeans(n_clusters=k, random_state=42, n_init=10)
    labels = km.fit_predict(X_cluster)
    print(
        k,
        "Silhouette:", silhouette_score(X_cluster, labels),
        "Davies-Bouldin:", davies_bouldin_score(X_cluster, labels),
        "Calinski-Harabasz:", calinski_harabasz_score(X_cluster, labels)
    )

# K-Means using the selected K from the experiment
k = 4
km = KMeans(n_clusters=k, random_state=42, n_init=10)
kmeans_labels = km.fit_predict(X_cluster)

# Hierarchical clustering
hier = AgglomerativeClustering(n_clusters=k, linkage="ward")
hier_labels = hier.fit_predict(X_cluster)

# PCA for dimensionality reduction
pca = PCA(n_components=2)
projection = pca.fit_transform(X_cluster)
print("Explained variance ratio:", pca.explained_variance_ratio_)

# ---------------- Model evaluation ----------------
features = [
    "Gender", "City", "Study_Hours", "Attendance_Percent",
    "Assignments_Completed", "Previous_Score", "Internet_Access"
]
X = df[features]
y = df["Placement"].map({"No": 0, "Yes": 1})

numeric = ["Study_Hours", "Attendance_Percent",
           "Assignments_Completed", "Previous_Score"]
categorical = ["Gender", "City", "Internet_Access"]

pre = ColumnTransformer([
    ("num", StandardScaler(), numeric),
    ("cat", OneHotEncoder(handle_unknown="ignore", drop="first"), categorical)
])

pipe = Pipeline([
    ("preprocess", pre),
    ("model", RandomForestClassifier(random_state=42))
])

params = {
    "model__n_estimators": [100, 150],
    "model__max_depth": [3, 5, None],
    "model__min_samples_split": [2, 5]
}

cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
grid = GridSearchCV(pipe, params, cv=cv, scoring="f1")
grid.fit(X, y)

scores = cross_val_score(grid.best_estimator_, X, y, cv=cv, scoring="f1")
print("Cross-validation F1:", scores)
print("Mean F1:", scores.mean())

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)
grid.best_estimator_.fit(X_train, y_train)
pred = grid.best_estimator_.predict(X_test)
prob = grid.best_estimator_.predict_proba(X_test)[:, 1]

print("Accuracy:", accuracy_score(y_test, pred))
print("Precision:", precision_score(y_test, pred, zero_division=0))
print("Recall:", recall_score(y_test, pred, zero_division=0))
print("F1:", f1_score(y_test, pred, zero_division=0))
print("ROC-AUC:", roc_auc_score(y_test, prob))
print("Best parameters:", grid.best_params_)
